/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gradecalculator;

/**
 *
 * @author lawler
 */
//public class GradeCalculator {
//
//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String[] args) {
//        // TODO code application logic here
//    }
//    
//}

import java.util.Scanner;

/**
 *
 * @author lawler
 */
public class GradeCalculator {

    /**
     * @param score
     * @param args the command line arguments
     * @return
     */
    public String getGrade(double score) {
        String grade = "";
        if (score >= 70 && score <= 100) {
            grade = "A";
        } else if (score >= 60 && score <= 69) {
            grade = "B";
        } else if (score >= 50 && score <= 59) {
            grade = "C";
        } else if (score >= 45 && score <= 49) {
            grade = "D";
        } else if (score >= 40 && score <= 44) {
            grade = "E";
        } else if(score > 0 && score <= 39){
            grade = "F";
        }
        return grade;
    }

    public int getPoint(String grade) {
        int point = 0;

        switch (grade) {
            case "A":
                point = 5;
                break;

            case "B":
                point = 4;
                break;

            case "C":
                point = 3;
                break;

            case "D":
                point = 2;
                break;

            case "E":
                point = 1;
                break;

            default:
                point = 0;
                break;
        }
        return point;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("SIMPLE GRADING SYSTEM");

        Scanner i = new Scanner(System.in);
        //course 1
        System.out.print("ENTER COURSE 1: " +"\n");
        String course1 = i.nextLine();

        System.out.print("Enter " + course1 + " course unit: " + "\n" );
        int courseUnit1 = i.nextInt();

        System.out.print("Enter " + course1 + " score: "+"\n");
        double score1 = i.nextDouble();

        i.nextLine();
        System.out.println(" ");
        
        
        //course2
        System.out.print("ENTER COURSE 2: " +"\n");
        String course2 = i.nextLine();

        System.out.print("Enter " + course2 + " course unit: " +"\n");
        int courseUnit2 = i.nextInt();

        System.out.print("Enter " + course2 + " score: " +"\n");
        double score2 = i.nextDouble();

        i.nextLine();
        System.out.println(" ");
        

        //course 3
        System.out.print("ENTER COURSE 3: " + "\n" );
        String course3 = i.nextLine();

        System.out.print("Enter " + course3 + " course unit: " +"\n");
        int courseUnit3 = i.nextInt();

        System.out.print("Enter " + course3 + " score: " +"\n");
        double score3 = i.nextDouble();

        i.nextLine();
        System.out.println(" ");
        

        //course 4
        System.out.print("ENTER COURSE 4: " +"\n");
        String course4 = i.nextLine();

        System.out.print("Enter " + course4 + " course unit: "+"\n");
        int courseUnit4 = i.nextInt();

        System.out.print("Enter " + course4 + " score: " +"\n");
        double score4 = i.nextDouble();

        i.nextLine();
        System.out.println(" ");
        

        //course 5
        System.out.print("ENTER COURSE 5: " +"\n");
        String course5 = i.nextLine();

        System.out.print("Enter " + course5 + " course unit: " +"\n");
        int courseUnit5 = i.nextInt();

        System.out.print("Enter " + course5 + " score: " +"\n");
        double score5 = i.nextDouble();

        //i.nextLine();
        GradeCalculator st = new GradeCalculator();

        String grade1 = st.getGrade(score1);
        String grade2 = st.getGrade(score2);
        String grade3 = st.getGrade(score3);
        String grade4 = st.getGrade(score4);
        String grade5 = st.getGrade(score5);

        int point1 = st.getPoint(grade1);
        int point2 = st.getPoint(grade2);
        int point3 = st.getPoint(grade3);
        int point4 = st.getPoint(grade4);
        int point5 = st.getPoint(grade5);

        //sum of all point 
       //double totalCourseUnit = courseUnit1 + courseUnit2 + courseUnit3 + courseUnit4 + courseUnit5;

    // sum of all grade unit
    double totalPoint = point1 + point2 + point3 + point4 + point5;
    
    // typecasting into double
    double totalGradeUnit = (double) totalPoint;
        
        //total quality  unit
        int totalQualityPoint = courseUnit1 * point1;
        totalQualityPoint += courseUnit2 * point2;
        totalQualityPoint += courseUnit3 * point3;
        totalQualityPoint += courseUnit4 * point4;
        totalQualityPoint += courseUnit5 * point5;
        
        
        // total grade unit
        //int totalGradeUnit = 

        //GPA calculation
        double gpa = totalQualityPoint / totalGradeUnit;

        System.out.println("|------------|----------------|---------|------------|");
        System.out.println("|COURSE CODE |  COURSE UNIT   |  GRADE  | GRADE UNIT |");
        System.out.println("|------------|----------------|---------|------------|");
        System.out.println("| " + course1+ "   |       " + courseUnit1 + "        |    " + grade1 + "    |    " + point1 + "       |");
        System.out.println("|------------|----------------|---------|------------|");
        System.out.println("| " + course2+  "     |       " + courseUnit2 + "        |    " + grade2 + "    |    " + point2 + "       |");
        System.out.println("|------------|----------------|---------|------------|");
        System.out.println("| " + course3+ "   |       " + courseUnit3 + "        |    " + grade3 + "    |    " + point3 + "       |");
        System.out.println("|------------|----------------|---------|------------|");
        System.out.println("| " + course4+ "     |       " + courseUnit4 + "        |    " + grade4 + "    |    " + point4 + "       |");
        System.out.println("|------------|----------------|---------|------------|");
        System.out.println("| " + course5    +      "   |       "  + courseUnit5 + "        |    " + grade5 + "    |    " + point5 + "        |");
        System.out.println("|------------|----------------|---------|------------|");
        System.out.println("");
        //System.out.println("the total point is: "+ totalPoint);
        //System.out.println("the total quality point is: "+ totalQualityPoint);
        System.out.format(" Your Gpa for the semester is: %.2f to 2 decimal places \n " , gpa );
    }

}

